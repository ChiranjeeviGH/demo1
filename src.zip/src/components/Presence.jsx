import { useReveal } from '../hooks/useReveal'
import DecorativePattern from './DecorativePattern'
import styles from './Presence.module.css'

export default function Presence() {
  const { ref, visible } = useReveal()

  return (
    <section id="presence" className={styles.section} ref={ref}>
      <DecorativePattern className={styles.pattern} size={280} opacity={0.12} />
      <div className={`${styles.inner} ${visible ? 'is-visible' : 'reveal'}`}>
        <h2>
          Our <em>Presence</em> Across Karnataka
        </h2>
        <p className={styles.intro}>
          Discover how SKDRDP is creating meaningful impact across districts through locally driven initiatives and community partnerships.
        </p>
        <div className={styles.layout}>
          <article className={styles.card}>
            <img
              className={styles.cardAsset}
              src="/Frame 180.png"
              alt="Mysuru district impact summary"
            />
          </article>
          <div className={styles.mapCard}>
            <img
              className={styles.mapAsset}
              src="/Frame 177.png"
              alt="Karnataka map showing Mysuru district"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
